
 var InsertWhere;
 var ChartOption;
 var QSServer;
 var AcctAppID;
 var OppAppID;
 var AcctField;
 var OppField ;
 
 var AC1;
 var AC2;
 var AC3;
 var AC4;

 var OC1;
 var OC2;
 var OC3;
 var OC4;
var settings;
var Pmode;







chrome.storage.local.get('qwm_Settings', function (result) {
    settings = result.qwm_Settings;
    var tobj = JSON.parse(settings);
    if( tobj.SFDCURL.toUpperCase().replace('HTTPS://','') == window.location.hostname.toUpperCase())
        {
        getSelectionTextAndContainerElement();
        }
    });

/*
 
 chrome.storage.local.get('qwmQSSERVER', function (result) {
    QSServer = result.qwmQSSERVER;
    
    });


 chrome.storage.local.get('qwm_AAPPID', function (result) {
					AcctAppID = result.qwm_AAPPID;
					
					});
 
  chrome.storage.local.get('qwm_APPFIELD', function (result) {
					AcctField = result.qwm_APPFIELD;
					
                    });
                    
 chrome.storage.local.get('qwm_OAPPID', function (result) {
				    OppAppID = result.qwm_OAPPID;
					
					});
 
  chrome.storage.local.get('qwm_OPPFIELD', function (result) {
					OppField = result.qwm_OPPFIELD;
					
					});                    
 


chrome.storage.local.get('qwm_OC1', function (result) {
         OC1 = result.qwm_OC1;
                });
chrome.storage.local.get('qwm_OC2', function (result) {
         OC2 = result.qwm_OC2;
                });
chrome.storage.local.get('qwm_OC3', function (result) {
         OC3 = result.qwm_OC3;
                });
chrome.storage.local.get('qwm_OC4', function (result) {
         OC4 = result.qwm_OC4;
                });

                    
chrome.storage.local.get('qwm_AC1', function (result) {
         AC1 = result.qwm_AC1;
                });
chrome.storage.local.get('qwm_AC2', function (result) {
         AC2 = result.qwm_AC2;
                });
chrome.storage.local.get('qwm_AC3', function (result) {
         AC3 = result.qwm_AC3;
                });
chrome.storage.local.get('qwm_AC4', function (result) {
         AC4 = result.qwm_AC4;
    
                });
                
                
  
//wait(4000);  //7 seconds in milliseconds
/*
var settings = `{
    "SFDCURL": "https://qlik.my.salesforce.com",
    "ServerName": "https://sense.qliktech.com",
    "AccountAppID": "App1",
    "AccountFieldName": "Field1",
    "AC1": {
      "id": "d441ba93-430d-48fd-9a4c-5aa55d4cc297",
      "width": "50%"
    },
    "AC2": {
      "id": "981dfc2a-41d1-46d8-a354-63feb2601ffb",
      "width": "50%"
    },
    "AC3": {
      "id": "d0876e5f-e521-4dba-93c8-396625b1f77e",
      "width": "50%"
    },
    "AC4": {
      "id": "7fabae3c-bb38-4fd6-b337-c279d2ca8190",
      "width": "50%"
    },
    "OppAppID": "1eb18da5-6a02-4e70-9879-60a3673880f4",
    "OppFieldName": "Opportunity ID",
    "OC1": {
      "id": "d441ba93-430d-48fd-9a4c-5aa55d4cc297",
      "width": "50%"
    },
    "OC2": {
      "id": "981dfc2a-41d1-46d8-a354-63feb2601ffb",
      "width": "50%"
    },
    "OC3": {
      "id": "d0876e5f-e521-4dba-93c8-396625b1f77e",
      "width": "50%"
    },
    "OC4": {
      "id": "7fabae3c-bb38-4fd6-b337-c279d2ca8190",
      "width": "50%"
    }
     
  }`;
  */



//document.getElementById("demo").innerHTML = obj.AcctAppID + ", " + obj.ServerName;





     function getSelectionTextAndContainerElement() {
        var obj = JSON.parse(settings);

        
            var InsertPage = '';

           var C1 = '';
           var C2 = '';
           var C3 = '';
           var C4 = '';

                        
           var pageTypeString = "mainTitle";
           var PagetypeObj = document.getElementsByClassName(pageTypeString);
            if(PagetypeObj.length >= 1){
            var PageType = PagetypeObj.item(0).innerText;
            //var sfdcval = window.location.href

            //var id = window.location.href;
            var sfdcval =  document.getElementsByClassName('innerLink').item(0).outerHTML.substr(document.getElementsByClassName('innerLink').item(0).outerHTML.search('subjectId&quot;:&quot;')+22,15);


            var sfdcval = Converto18(sfdcval);
             //var sfdcval = id.substr(id.length - 15);

            var var_basechart = "<iframe src='{server}/single/?appid={appid}&obj={Chart}&select=clearall&select={AccfieldName},{AccN},n/a&identity={AccN}' style='border:none;width:{w};height:450px;'></iframe>";          

                if(PageType=='Account Detail' && obj.AccountAppID.length > 9)
                    {
                        InsertPage = 'acct'
                        
                        //var_basechart = var_basechart.replace('{server}', QSServer);
                        //var_basechart = var_basechart.replace('{appid}', AcctAppID);
                        //var_basechart = var_basechart.replace('{AccfieldName}', AcctField);
                        //var_basechart = var_basechart.replace('{AccN}', sfdcval);
                        //var_basechart = var_basechart.replace('{AccN}', sfdcval);


                        var_basechart = var_basechart.replace('{server}', obj.ServerName);
                        var_basechart = var_basechart.replace('{appid}', obj.AccountAppID);
                        var_basechart = var_basechart.replace('{AccfieldName}', obj.AccountFieldName);
                        var_basechart = var_basechart.replace('{AccN}', sfdcval);
                        var_basechart = var_basechart.replace('{AccN}', sfdcval);                        

/*
                       if(AC2.length > 3  )
                       {
                           C2 = var_basechart.replace('{Chart}', AC2);
                           C2 = C2.replace('X%', '49%') ;

                           C1 = var_basechart.replace('{Chart}', AC1);
                           C1 = C1.replace('X%', '49%') ;

                       }

*/
                        //C1 = var_basechart.replace('{Chart}', AC1);
                        //C2 = var_basechart.replace('{Chart}', AC2);
                        //C3 = var_basechart.replace('{Chart}', AC3);
                        //C4 = var_basechart.replace('{Chart}', AC4);
                        
                        C1 = var_basechart.replace('{Chart}', obj.AC1.id);
                        C1 = C1.replace('{w}', obj.AC1.width);

                        C2 = var_basechart.replace('{Chart}', obj.AC2.id);
                        C2 = C2.replace('{w}', obj.AC2.width);

                        C3 = var_basechart.replace('{Chart}', obj.AC3.id);
                        C3 = C3.replace('{w}', obj.AC3.width);

                        C4 = var_basechart.replace('{Chart}', obj.AC4.id);
                        C4 = C4.replace('{w}', obj.AC4.width);

                

                    }
                if(PageType=='Opportunity Detail' && obj.OppAppID.length > 9 )
                    {
                        InsertPage = 'opp'
                        //var_basechart = var_basechart.replace('{server}', QSServer);
                        //var_basechart = var_basechart.replace('{appid}', OppAppID);
                        //var_basechart = var_basechart.replace('{AccfieldName}', OppField);
                        //var_basechart = var_basechart.replace('{AccN}', sfdcval);
                        //var_basechart = var_basechart.replace('{AccN}', sfdcval);
                        var_basechart = var_basechart.replace('{server}', obj.ServerName);
                        var_basechart = var_basechart.replace('{appid}', obj.OppAppID);
                        var_basechart = var_basechart.replace('{AccfieldName}', obj.OppFieldName);
                        var_basechart = var_basechart.replace('{AccN}', sfdcval);
                        var_basechart = var_basechart.replace('{AccN}', sfdcval);                         


                        C1 = var_basechart.replace('{Chart}', obj.OC1.id);
                        C1 = C1.replace('{w}', obj.OC1.width);
                        
                        C2 = var_basechart.replace('{Chart}', obj.OC2.id);
                        C2 = C2.replace('{w}', obj.OC2.width);

                        C3 = var_basechart.replace('{Chart}', obj.OC3.id);
                        C3 = C3.replace('{w}', obj.OC3.width);

                        C4 = var_basechart.replace('{Chart}', obj.OC4.id);
                        C4 = C4.replace('{w}', obj.OC4.width);
                    }                   
            }
         





        //    var varDisplayElement = "topName";
         //   var displayObj = document.getElementsByClassName(varDisplayElement);

         //   var varSearchElement = "acc2_ileinner";
         //   var searchObj = document.getElementById(varSearchElement);
        
            
         //   var varSearchClass = "pbSubsection";
            varSearchClass = 'fewerMore';
            var classObj = document.getElementsByClassName(varSearchClass);

            if(classObj.length == 1)
            {
            

                    if( InsertPage == 'acct' || InsertPage == 'opp'  )
                    {
                                
                        classObj.item(0).innerHTML =   `<div id="QStooltip1" style={width: 100%; }>` +  C1  + C2 + C3 + C4 + '</div>' + classObj.item(0).innerHTML ;
                
                    }

        
            }        

        }

     
 



        function wait(ms){
            var start = new Date().getTime();
            var end = start;
            while(end < start + ms) {
              end = new Date().getTime();
           }
         }

   

        function Converto18(id) {
            if (id == null) return id;
            var input=id;
            var output;
                if(input.length == 15){
                    var addon="";
                    for(var block=0;block<3; block++)
                    {
                        var loop=0;
                        for(var position=0;position<5;position++){
                            var current=input.charAt(block*5+position);
                            if(current>="A" && current<="Z")
                                loop+=1<<position;
                        }
                        addon+="ABCDEFGHIJKLMNOPQRSTUVWXYZ012345".charAt(loop);
                    }
                    output=(input+addon);
                }
                else{
                  
                    return 'error';
                }
            return output;
        }
    
      //   window.addEventListener('load', function(){
            // Everything has loaded!cc

    
       //     getSelectionTextAndContainerElement();
       //   });

