
 var InsertWhere;
 var ChartOption;
 var OptionEnable;
 
 var C1;
 var C2;
 var C3;
 var C4;
var Pmode;


 
//addheader();


 //findAndReplace('(desktop|apple|sony)', "<script>$(function() { var self = $('.hover-popup');self.mouseover(function () {      self.next().children('.popup-box').fadeIn(350);});self.mouseout(function () {     self.next().children('.popup-box').fadeOut(350);});  });</script>   <a class='hover-popup' href='#''>$1 HELLLOOO</a>   <section class='popup-container'> <div class='popup-box'>     <p>zzzzzzzzzz</p> </div></section>");


 


 chrome.storage.local.get('qwmenable', function (result) {
					OptionEnable = result.qwmenable;
					
					});
 
 
chrome.storage.local.get('qwminsert', function (result) {
					InsertWhere = result.qwminsert;
					
					});
					
		

chrome.storage.local.get('qwmsubject', function (result) {
					ChartOption = result.qwmsubject;
					
                    });	
                    
chrome.storage.local.get('qwmC1', function (result) {
         C1 = result.qwmC1;
                });
chrome.storage.local.get('qwmC2', function (result) {
         C2 = result.qwmC2;
                });
chrome.storage.local.get('qwmC3', function (result) {
         C3 = result.qwmC3;
                });
chrome.storage.local.get('qwmC4', function (result) {
         C4 = result.qwmC4;
                });
        
					
chrome.storage.onChanged.addListener(function(changes, area) {
    if (area == "local" && "qwminsert" in changes) {
        InsertWhere = changes.qwminsert.newValue;
    }
	
    if (area == "local" && "qwmsubject" in changes) {
        ChartOption = changes.qwmsubject.newValue;
    }	
	
    if (area == "local" && "qwmenable" in changes) {
        OptionEnable = changes.qwmenable.newValue;
    }	

    if (area == "local" && "qwmC1" in changes) {
        C1 = changes.qwmC1.newValue;
    }	    	
    if (area == "local" && "qwmC2" in changes) {
        C2 = changes.qwmC2.newValue;
    }	  
    if (area == "local" && "qwmC3" in changes) {
        C3 = changes.qwmC3.newValue;
    }	  
    if (area == "local" && "qwmC4" in changes) {
        C4 = changes.qwmC4.newValue;
    }	              
});


//if(OptionEnable)
//{
	//document.body.addEventListener("mouseup", getSelectionTextAndContainerElement);
//}
var newcss = `
<style>
#Qtooltip1 { position: relative; }
#Qtooltip1 t z { display: none; color: #FFFFFF; }
#Qtooltip1 t:hover z { display: block; position: fixed; z-index: 1000; width: 600px; background-color:red;  height: 500px; left: 30%; top: 0px; color: #FFFFFF; padding: 0 5px; }
</style>`;
  

var target = `
                <p class="link" id="tooltip1"><a href="introduction.php">Introduction<div style="height: 300px; width: 400px; ">
                    this is test  
                </div>    </a></p>`;

document.body.innerHTML = newcss + document.body.innerHTML;

document.body.addEventListener("mouseup", 
function(e){
    var isCtrlPressed = e.shiftKey;
  if(isCtrlPressed==true)
    {
      getSelectionTextAndContainerElement()
    }
  }
);
     function getSelectionTextAndContainerElement() {
		 
		 /*
		 if(OptionEnable.checked){
         var selectedText = document.getSelection();
		 }
		 */
         var classobj = document.getElementsByClassName("pageDescription");
       
varafter = `<iframe src='https://qsdemo/single/?appid=bc017a30-0dc5-43fb-84bc-671b0f7199ef&obj=GdjmWq&opt=nointeraction&select=clearall' style='border:none;width:100%;height:100%;'></iframe>`

//varafter = '<div style="height: 500px; width: 600px;"> </div>';
         classobj.item(0).innerHTML =   `<div id="Qtooltip1"><t>` + classobj.item(0).innerHTML + '<z>' +  varafter + '</z></t></div>';
         
         
         if(classobj.item.length = 2)
         {
             var vart = classobj.item(0);

             var range = document.createRange();
             

             
             range.selectNode(vart);
             

             var newNode = document.createElement("div");
             newNode.setAttribute(
                "id",
                "Qtooltip1"
             );

       

             range.surroundContents(newNode);

             
         }


         var all = document.getElementsByTagName("*");

   /*       for (var i = 0, max = all.length; i < max; i++) {
             // Do something with the element here
             all[i].setAttribute('style', ''); //  all[i].getAttribute('style').replace('; background-color: yellow; display: inline', ''));
         } */

         var text = "", containerElement = null;
         if (typeof window.getSelection != "undefined") {
             var sel = window.getSelection();
             // if (sel.rangeCount) {
				 if (sel.toString().length > 3) {
					 
					 
				
				 
				     var elem = document.getElementById('wmmashup');
					 if( elem !== null){
							elem.parentNode.removeChild(elem);
					 }
					 
					 if(ChartOption=='sales')
					 {
						var Chart1 = 'https://sense-demo.qlik.com/site/single/?appid=372cbc85-f7fb-4db6-a620-9a5367845dce&obj=MEAjCJ&select=clearall';
						var Chart2 = 'https://sense-demo.qlik.com/site/single/?appid=372cbc85-f7fb-4db6-a620-9a5367845dce&obj=fQdkG&select=clearall';
						var Chart3 = 'https://sense-demo.qlik.com/site/single/?appid=372cbc85-f7fb-4db6-a620-9a5367845dce&obj=NrHfp&select=clearall';
						var Chart4 = 'https://sense-demo.qlik.com/site/single/?appid=372cbc85-f7fb-4db6-a620-9a5367845dce&obj=bsxkrg&select=clearall';		
					 }
					
					
					 if(ChartOption=='healthcare')
					 {
						//If MyTopic = "healthcare" Then
						var Chart1 = "https://sense-demo.qlik.com/site/single/?appid=67dd73b4-18e4-420f-bac8-710d3834cb8d&obj=UumJNG&select=clearall";
						var Chart2 = "https://sense-demo.qlik.com/site/single/?appid=67dd73b4-18e4-420f-bac8-710d3834cb8d&obj=QwVdJw&select=clearall";
						var Chart3 = "https://sense-demo.qlik.com/site/single/?appid=67dd73b4-18e4-420f-bac8-710d3834cb8d&obj=QWrwUe&select=clearall";
						var Chart4 = "https://sense-demo.qlik.com/site/single/?appid=67dd73b4-18e4-420f-bac8-710d3834cb8d&obj=FyZj&select=clearall";
					 }

		 

					 if(ChartOption=='insurance')
					 {
						//If MyTopic = "insurance" Then
						var Chart1 = "https://sense-demo.qlik.com/sso/single/?appid=a6102fcb-b5f5-4f04-b554-880417f45475&obj=xZjjzG&select=clearall";
						var Chart2 = "https://sense-demo.qlik.com/sso/single/?appid=a6102fcb-b5f5-4f04-b554-880417f45475&obj=CZDPm&select=clearall";
						var Chart3= "https://sense-demo.qlik.com/sso/single/?appid=a6102fcb-b5f5-4f04-b554-880417f45475&obj=MNqRw&select=clearall";
						var Chart4 = "https://sense-demo.qlik.com/sso/single/?appid=a6102fcb-b5f5-4f04-b554-880417f45475&obj=ndRYLxV&select=clearall";
					 }

					 if(ChartOption=='banking')
					 {
						//If MyTopic = "banking" Then
						var Chart1  = "https://sense-demo.qlik.com/site/single/?appid=ec296874-47bf-48e4-822f-0cc4e1068723&obj=mptRDY&select=clearall";
						var Chart2  = "https://sense-demo.qlik.com/site/single/?appid=ec296874-47bf-48e4-822f-0cc4e1068723&obj=mHjBYV&select=clearall";
						var Chart3  = "https://sense-demo.qlik.com/site/single/?appid=ec296874-47bf-48e4-822f-0cc4e1068723&obj=UgUAhjK&select=clearall";
						var Chart4  = "https://sense-demo.qlik.com/site/single/?appid=ec296874-47bf-48e4-822f-0cc4e1068723&obj=fYszy&select=clearall";
					 }        

					
					 if(ChartOption=='custom')
					 {
						//If MyTopic = "custom" Then
						var Chart1  = C1;
						var Chart2  = C2;
						var Chart3  = C3;
						var Chart4  = C4;
					 }        
					
					
				//var vChart = '<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"><script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script><script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script><script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script><div id="wmmashup"><div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel"><div class="carousel-inner"><div class="carousel-item"><iframe class="d-block w-100" style="width: 90%; height:400px;" src=" Chart1 "></iframe></div><div class="carousel-item"><iframe class="d-block w-100" style="width: 90%; height:400px;" src=" Chart2 "></iframe></div><div class="carousel-item active"><iframe class="d-block w-100" style="width: 90%; height:400px;" src=" Chart3 "></iframe></div></div></div></div>';	 
					 
				var vChart  = '<div id="wmmashup"><br><div style="width:100%; min-width:800px; height: 800px; border:none;"><iframe style="width:49.5%; padding-right:1%; min-width:400px; border:none;" height="400px" src=" Chart1 "></iframe><iframe style="width:49.5%; min-width:400px; border:none;" height="400px" src=" Chart2 "></iframe><br><iframe style="width:49.5%; padding-right:1%; min-width:400px; border:none;" height="400px" src=" Chart3 "></iframe><iframe style="width:49.5%; min-width:400px; border:none;" height="400px" src=" Chart4 "></iframe></div></div>';
									 
					 vChart = vChart.replace('Chart1', Chart1);
					 vChart = vChart.replace("Chart2", Chart2);
					 vChart = vChart.replace("Chart3", Chart3);
					 vChart = vChart.replace("Chart4", Chart4);
					 
					 
				 		 
				 
                     
				 
				 
					 var node = sel.getRangeAt(0).commonAncestorContainer;
					 containerElement = node.nodeType == 1 ? node : node.parentNode;
					 
					 /* containerElement.setAttribute('style', containerElement.getAttribute('style') + '; background-color: yellow; display: inline'); */
		 if(OptionEnable){			 
					 if(InsertWhere=='before')
						 {
						 containerElement.outerHTML = vChart + containerElement.outerHTML ;
						 } 
						 else {
							containerElement.outerHTML =  containerElement.outerHTML + vChart; 
						 }
		 }
					 //alert(containerElement.outerHTML);
					 //window.parent.setText(containerElement.outerHTML);
					 //window.parent.setText(text);
					 // window.parent.setText(containerElement.innerHTML.replace(/(\r\n)/g, "").trim());
             }
         } else if (typeof document.selection != "undefined" &&
                    document.selection.type != "Control") {
             var textRange = document.selection.createRange();
             containerElement = textRange.parentElement();
             text = textRange.text;
            // alert(containerElement.outerHTML);
             //             document.parent.setText(containerElement.outerHTML);
             //document.parent.setText(text);
             document.parent.setText(containerElement.innerHTML.replace(/(\r\n)/g, "").trim());
         }
         return {
             text: text,
             containerElement: containerElement
         };
     }
 

     function getSafeRanges(dangerous) {
         var a = dangerous.commonAncestorContainer;
         // Starts -- Work inward from the start, selecting the largest safe range
         var s = new Array(0), rs = new Array(0);
         if (dangerous.startContainer != a)
             for (var i = dangerous.startContainer; i != a; i = i.parentNode)
                 s.push(i)
         ;
         if (0 < s.length) for (var i = 0; i < s.length; i++) {
             var xs = document.createRange();
             if (i) {
                 xs.setStartAfter(s[i - 1]);
                 xs.setEndAfter(s[i].lastChild);
             }
             else {
                 xs.setStart(s[i], dangerous.startOffset);
                 xs.setEndAfter(
                     (s[i].nodeType == Node.TEXT_NODE)
                     ? s[i] : s[i].lastChild
                 );
             }
             rs.push(xs);
         }

         // Ends -- basically the same code reversed
         var e = new Array(0), re = new Array(0);
         if (dangerous.endContainer != a)
             for (var i = dangerous.endContainer; i != a; i = i.parentNode)
                 e.push(i)
         ;
         if (0 < e.length) for (var i = 0; i < e.length; i++) {
             var xe = document.createRange();
             if (i) {
                 xe.setStartBefore(e[i].firstChild);
                 xe.setEndBefore(e[i - 1]);
             }
             else {
                 xe.setStartBefore(
                     (e[i].nodeType == Node.TEXT_NODE)
                     ? e[i] : e[i].firstChild
                 );
                 xe.setEnd(e[i], dangerous.endOffset);
             }
             re.unshift(xe);
         }

         // Middle -- the uncaptured middle
         if ((0 < s.length) && (0 < e.length)) {
             var xm = document.createRange();
             xm.setStartAfter(s[s.length - 1]);
             xm.setEndBefore(e[e.length - 1]);
         }
         else {
             return [dangerous];
         }

         // Concat
         rs.push(xm);
         response = rs.concat(re);

         // Send to Console
         return response;
     }

     function highlightRange(range) {
         var newNode = document.createElement("div");
         newNode.setAttribute(
            "style",
            "background-color: yellow; display: inline;"
         );
         range.surroundContents(newNode);
     }
	 
     function findAndReplace(searchText, replacement, searchNode) {
        if (!searchText || typeof replacement === 'undefined') {
            // Throw error here if you want...
            return;
        }
        var regex = typeof searchText === 'string' ?
                    new RegExp(searchText, 'g') : searchText,
            childNodes = (searchNode || document.body).childNodes,
            cnLength = childNodes.length,
            excludes = 'html,head,style,title,link,meta,script,object,iframe';
        while (cnLength--) {
            var currentNode = childNodes[cnLength];
            if (currentNode.nodeType === 1 &&
                (excludes + ',').indexOf(currentNode.nodeName.toLowerCase() + ',') === -1) {
                arguments.callee(searchText, replacement, currentNode);
            }
            if (currentNode.nodeType !== 3 || !regex.test(currentNode.data) ) {
                continue;
            }
            var parent = currentNode.parentNode,
                frag = (function(){
                    var html = currentNode.data.replace(regex, replacement),
                        wrap = document.createElement('div'),
                        frag = document.createDocumentFragment();
                    wrap.innerHTML = html;
                    while (wrap.firstChild) {
                        frag.appendChild(wrap.firstChild);
                    }
                    return frag;
                })();
            parent.insertBefore(frag, currentNode);
            parent.removeChild(currentNode);
        }
    }


function addheader() {
    document.head.innerHTML = document.head.innerHTML + '  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"> <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script> <script>$(document).ready(function(){    $("[data-toggle="popover"]").popover({ html : true});   });</script>';
}





    


