var obj;





function save_options() {
 
  //var QSSettings = document.getElementById('QSSettings').value;
//  var QSSettings = JSON.stringify(obj);
  
  var AC1 = document.getElementById('AC1').value;
  var AC2 = document.getElementById('AC2').value;
  var AC3 = document.getElementById('AC3').value;
  var AC4 = document.getElementById('AC4').value;

  var AC1W = document.getElementById('AC1W').value;
  var AC2W = document.getElementById('AC2W').value;
  var AC3W = document.getElementById('AC3W').value;
  var AC4W = document.getElementById('AC4W').value;



  var OC1 = document.getElementById('OC1').value;
  var OC2 = document.getElementById('OC2').value;
  var OC3 = document.getElementById('OC3').value;
  var OC4 = document.getElementById('OC4').value;

  var OC1W = document.getElementById('OC1W').value;
  var OC2W = document.getElementById('OC2W').value;
  var OC3W = document.getElementById('OC3W').value;
  var OC4W = document.getElementById('OC4W').value;

  var varSFDCURL = document.getElementById('SFDCURL').value;
  var varserver = document.getElementById('QSSERVER').value;
  var varAcctAppID = document.getElementById('AAPPID').value;
  var varOppAppID = document.getElementById('OAPPID').value;

  var varAppField = document.getElementById('APPFIELD').value;
  var varOppField = document.getElementById('OPPFIELD').value;
  




/*
  chrome.storage.local.set({'qwm_AC1': AC1});
  chrome.storage.local.set({'qwm_AC2': AC2});
  chrome.storage.local.set({'qwm_AC3': AC3});
  chrome.storage.local.set({'qwm_AC4': AC4});
  

  chrome.storage.local.set({'qwm_OC1': OC1});
  chrome.storage.local.set({'qwm_OC2': OC2});
  chrome.storage.local.set({'qwm_OC3': OC3});
  chrome.storage.local.set({'qwm_OC4': OC4});

  chrome.storage.local.set({'qwmQSSERVER': varserver});
  chrome.storage.local.set({'qwm_AAPPID': varAcctAppID});
  chrome.storage.local.set({'qwm_OAPPID': varOppAppID});
  
  chrome.storage.local.set({'qwm_APPFIELD': varAppField});

  chrome.storage.local.set({'qwm_Settings': QSSettings});
*/
obj.ServerName = varserver;
obj.SFDCURL = varSFDCURL;
obj.AccountAppID = varAcctAppID;
obj.AccountFieldName = varAppField;
obj.OppAppID = varOppAppID;
obj.OppFieldName = varOppField;


obj.AC1.id = AC1;
obj.AC2.id = AC2;
obj.AC3.id = AC3;
obj.AC4.id = AC4;

obj.AC1.width = AC1W;
obj.AC2.width = AC2W;
obj.AC3.width = AC3W;
obj.AC4.width = AC4W;

obj.OC1.id = OC1;
obj.OC2.id = OC2;
obj.OC3.id = OC3;
obj.OC4.id = OC4;

obj.OC1.width = OC1W;
obj.OC2.width = OC2W;
obj.OC3.width = OC3W;
obj.OC4.width = OC4W;

var QSSettings = JSON.stringify(obj);

  //chrome.storage.local.set({'qwm_OPPFIELD': varOppField}, function() {
  chrome.storage.local.set({'qwm_Settings': QSSettings}, function() {
    // Update status to let user know options were saved.
    var status = document.getElementById('status');
    status.style.display = "block"; 
    status.textContent = 'Options saved.';
    setTimeout(function() {
      status.textContent = '';
	  status.style.display = "none"; 
    }, 750);
  });


}

// Restores select box and checkbox state using the preferences
// stored in chrome.storage.
function restore_options() {
  // Use default value color = 'red' and likesColor = true.
  

  chrome.storage.local.get('qwm_Settings', function (result) {
    //document.getElementById('QSSettings').value = result.qwm_Settings;


    if(result.qwm_Settings == undefined)
    {

      tempsettings = `
      {
        "SFDCURL": "https://YourCompany.salesforce.com",
        "ServerName": "https://QlikSenseServerName",
        "AccountAppID": "AppId-For-Accounts-Page",
        "AccountFieldName": "QS FieldName with AccountID",
        "AC1": {
          "id": "VisualizationID",
          "width": "50%"
        },
        "AC2": {
          "id": "VisualizationID",
          "width": "50%"
        },
        "AC3": {
          "id": "VisualizationID",
          "width": "50%"
        },
        "AC4": {
          "id": "VisualizationID",
          "width": "50%"
        },
        "OppAppID": "AppId-For-Opportunity-Page",
        "OppFieldName": "QS FieldName with Opportunty ID",
        "OC1": {
          "id": "VisualizationID",
          "width": "50%"
        },
        "OC2": {
          "id": "VisualizationID",
          "width": "50%"
        },
        "OC3": {
          "id": "VisualizationID",
          "width": "50%"
        },
        "OC4": {
          "id": "VisualizationID",
          "width": "50%"
        }
      }
      `;

      chrome.storage.local.set({'qwm_Settings': tempsettings});
      result.qwm_Settings = tempsettings;
    }

    document.getElementById('QSSettings').value = result.qwm_Settings;


     obj = JSON.parse(result.qwm_Settings);
     document.getElementById('SFDCURL').value = obj.SFDCURL;
    document.getElementById('QSSERVER').value = obj.ServerName;
    document.getElementById('AAPPID').value = obj.AccountAppID;
    document.getElementById('OAPPID').value = obj.OppAppID;
    document.getElementById('APPFIELD').value = obj.AccountFieldName;
    document.getElementById('OPPFIELD').value = obj.OppFieldName;

    document.getElementById('AC1').value = obj.AC1.id;
    document.getElementById('AC1W').value = obj.AC1.width;

    document.getElementById('AC2').value = obj.AC2.id;
    document.getElementById('AC2W').value = obj.AC2.width;

    document.getElementById('AC3').value = obj.AC3.id;
    document.getElementById('AC3W').value = obj.AC3.width;

    document.getElementById('AC4').value = obj.AC4.id;
    document.getElementById('AC4W').value = obj.AC4.width;

    document.getElementById('OC1').value = obj.OC1.id;
    document.getElementById('OC1W').value = obj.OC1.width;

    document.getElementById('OC2').value = obj.OC2.id;
    document.getElementById('OC2W').value = obj.OC2.width;

    document.getElementById('OC3').value = obj.OC3.id;
    document.getElementById('OC3W').value = obj.OC3.width;

    document.getElementById('OC4').value = obj.OC4.id;
    document.getElementById('OC4W').value = obj.OC4.width;

    });	

/*
  chrome.storage.local.get('qwmQSSERVER', function (result) {
					document.getElementById('QSSERVER').value = result.qwmQSSERVER;
					});	
  

  chrome.storage.local.get('qwm_AAPPID', function (result) {
					document.getElementById('AAPPID').value = result.qwm_AAPPID;
          });	   
          
          
  chrome.storage.local.get('qwm_OAPPID', function (result) {
					document.getElementById('OAPPID').value = result.qwm_OAPPID;
          });	             
          
          

  chrome.storage.local.get('qwm_APPFIELD', function (result) {
					document.getElementById('APPFIELD').value = result.qwm_APPFIELD;
          });	    
          
  chrome.storage.local.get('qwm_OPPFIELD', function (result) {
					document.getElementById('OPPFIELD').value = result.qwm_OPPFIELD;
          });	    
          
          
          
  chrome.storage.local.get('qwm_AC1', function (result) {
					document.getElementById('AC1').value = result.qwm_AC1;
          });	    

  chrome.storage.local.get('qwm_AC2', function (result) {
					document.getElementById('AC2').value = result.qwm_AC2;
          });	              

  chrome.storage.local.get('qwm_AC3', function (result) {
					document.getElementById('AC3').value = result.qwm_AC3;
          });	    
          
  chrome.storage.local.get('qwm_AC4', function (result) {
					document.getElementById('AC4').value = result.qwm_AC4;
          });	              
       


  chrome.storage.local.get('qwm_OC1', function (result) {
					document.getElementById('OC1').value = result.qwm_OC1;
          });	    

  chrome.storage.local.get('qwm_OC2', function (result) {
					document.getElementById('OC2').value = result.qwm_OC2;
          });	              

  chrome.storage.local.get('qwm_OC3', function (result) {
					document.getElementById('OC3').value = result.qwm_OC3;
          });	    
          
  chrome.storage.local.get('qwm_OC4', function (result) {
					document.getElementById('OC4').value = result.qwm_OC4;
          });	          
*/
}



function load_options() {

  var QSSettings = document.getElementById('QSSettings').value;
  chrome.storage.local.set({'qwm_Settings': QSSettings}, function() {
    // Update status to let user know options were saved.
    var status = document.getElementById('loadstatus');
    status.style.display = "block"; 

   
    status.textContent = 'Settings Loaded';
    setTimeout(function() {
      status.textContent = '';
	  status.style.display = "none"; 
    }, 750);
  });

  chrome.storage.local.get('qwm_Settings', function (result) {
  restore_options();
  });

}


 
function LoadAppList(){

}



function LoadApps(){
  var varserver = obj.ServerName;
    
    
  var config = {
      host: varserver,
      prefix: '/',
      port: 443,
      isSecure: true
  };
  require.config( {
      baseUrl: ( config.isSecure ? "https://" : "http://" ) + config.host + (config.port ? ":" + config.port : "") + config.prefix + "resources"
  } );
  
  require( ["js/qlik"], function ( qlik ) {
      qlik.setOnError( function ( error ) {
          $( '#popupText' ).append( error.message + "<br>" );
          $( '#popup' ).fadeIn( 1000 );
      } );
      $( "#closePopup" ).click( function () {
          $( '#popup' ).hide();
      } );
  
      //callbacks -- inserted here --
      //open apps -- inserted here --
      var app = qlik.openApp('1eb18da5-6a02-4e70-9879-60a3673880f4', config);
      app.getObject('QV01','DPGjuY');
  
  });
  }

document.addEventListener('DOMContentLoaded', restore_options);
document.getElementById('save').addEventListener('click',
    save_options);

    document.getElementById('load').addEventListener('click',
    load_options);    

    document.getElementById('qsconnect').addEventListener('click',
    LoadApps);    

  